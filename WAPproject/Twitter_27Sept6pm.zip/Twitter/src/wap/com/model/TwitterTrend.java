package wap.com.model;

public class TwitterTrend {

}
